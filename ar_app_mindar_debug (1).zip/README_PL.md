# AR-APP — wersja diagnostyczna MindAR

Wgraj do GitHuba:

```
index.html
microscope.glb
microscope_reference_photo.png
targets.mind
```

Plik musi nazywać się dokładnie `targets.mind`.

Po uruchomieniu kliknij `Sprawdź pliki`.
Jeżeli którykolwiek plik pokaże BŁĄD 404, aplikacja nie ma do niego dostępu.
